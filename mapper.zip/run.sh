rm *HASH*.json
node --max-old-space-size=4096 main.js